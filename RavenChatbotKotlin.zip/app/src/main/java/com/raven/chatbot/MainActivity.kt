package com.raven.chatbot

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val chatbot = Chatbot()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val input = findViewById<EditText>(R.id.messageInput)
        val send = findViewById<Button>(R.id.sendButton)
        val chat = findViewById<TextView>(R.id.chatText)
        val scroll = findViewById<ScrollView>(R.id.chatScroll)

        fun sendMessage() {
            val message = input.text.toString().trim()
            if (message.isEmpty()) return

            chat.append("\nYou: $message\n")
            val response = chatbot.respond(message)
            chat.append("Raven: $response\n")
            input.text.clear()

            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }

            if (message.equals("quit", ignoreCase = true)) {
                input.isEnabled = false
                send.isEnabled = false
            }
        }

        send.setOnClickListener { sendMessage() }
        input.setOnEditorActionListener { _, _, _ ->
            sendMessage()
            true
        }
    }
}
