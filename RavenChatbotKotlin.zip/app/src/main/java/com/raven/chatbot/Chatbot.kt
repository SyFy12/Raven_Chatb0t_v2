package com.raven.chatbot

class Chatbot {
    fun respond(input: String): String {
        return when (input.trim().lowercase()) {
            "hello", "hi", "hey" ->
                "Hello! How can I assist you today!"

            "how are you" ->
                "I'm just a program, but I'm doing great! How about you?"

            "what is your name" ->
                "I'm your friendly chatbot. What's your name?"

            "quit" ->
                "Goodbye! Have a great day!"

            else ->
                "I'm not sure I understand. Can you rephrase?"
        }
    }
}
