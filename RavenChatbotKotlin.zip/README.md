# Raven Chatbot - Kotlin Android App

Converted from the uploaded Java chatbot.

## Build in Android Studio
1. Open this folder as an Android Studio project.
2. Let Gradle sync.
3. Select **Build > Build APK(s)**.
4. The debug APK will be under:
   `app/build/outputs/apk/debug/app-debug.apk`

## Build from Linux Mint
Install Android Studio or a compatible Android SDK/Gradle setup, then from this folder run:

```bash
./gradlew assembleDebug
```

The app package is `com.raven.chatbot`.
